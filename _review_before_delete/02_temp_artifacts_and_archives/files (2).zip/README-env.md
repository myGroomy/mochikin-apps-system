# Matriks env MOCHIKIN-APPS

Legenda: `=` wajib dan nilainya harus SAMA di semua app yang memakainya.
`≠` wajib tetapi nilainya harus BEDA per app. `o` opsional. `-` tidak dipakai.

| Variabel | launcher | stokis | mycheck | mycustomer | myperformance |
|---|---|---|---|---|---|
| LAUNCHER_SSO_SHARED_SECRET | = | = | = | = | = |
| MOCHIKIN_EVENTS_SECRET | = | = | = | = | = |
| SESSION_SECRET (>= 32 karakter) | ≠ | ≠ | ≠ | ≠ | o |
| LAUNCHER_SESSION_SECRET | ≠ | - | - | - | - |
| STOKIS_API_KEY (kunci session stokis) | - | ≠ | - | - | - |
| SUPABASE_URL / ANON_KEY / SERVICE_ROLE_KEY | = | = | = | = | = |
| NEXT_PUBLIC_SUPABASE_URL / ANON_KEY | - | - | - | - | = |
| UPSTASH_REDIS_REST_URL / TOKEN | = | = | = | = | = |
| GOOGLE_SERVICE_ACCOUNT_EMAIL / PRIVATE_KEY | = | = | = | = | - |
| REGISTRY_SPREADSHEET_ID | ≠ | ≠ | ≠ | - | - |
| GOOGLE_SPREADSHEET_ID | - | - | - | ≠ | - |
| FOLDER_DRIVE_INDUK / GOOGLE_DRIVE_FOLDER_ID | o | o | ≠ | - | - |
| CRON_SECRET | - | - | ≠ | - | ≠ |
| MYPERFORMANCE_URL (endpoint lengkap) | - | = | = | = | - |
| APP_TIMEZONE | o | = | = | = | = |
| AUTH_ALLOW_DEV_HEADERS (harus false) | - | - | - | - | ≠ |

## Aturan penting
1. Isi di Vercel per project (Settings > Environment Variables), bukan di root repo.
2. Isi untuk Production dan Preview. Variabel NEXT_PUBLIC_* butuh redeploy agar berlaku.
3. REGISTRY_SPREADSHEET_ID punya nama sama tetapi spreadsheet BERBEDA per app. Jangan disalin antar app.
4. Private key Google: satu baris, newline sebagai `\n`, dibungkus tanda kutip ganda.
5. Share setiap spreadsheet dan folder Drive ke email service account sebagai Editor.
6. Secret >= 32 karakter. LAUNCHER_SSO_SHARED_SECRET dan MOCHIKIN_EVENTS_SECRET diganti serentak di semua app.
7. Jangan pernah memakai nilai contoh atau nilai asli yang pernah ter-commit; buat ulang jika bocor.

## Cek setelah deploy
- Login launcher berhasil (bukan 503), lalu buka stokis/mycustomer lewat handoff.
- POST event palsu ke /api/events/emit tanpa signature harus ditolak 401.
- Header X-Person-Id tanpa token ke API myperformance harus ditolak 401.
- Cron rollup-daily terjadwal dan berhasil di log Vercel.
